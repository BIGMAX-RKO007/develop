import React from 'react'

export default class Profile extends React.Component {
  render() {
    return <div>我的个人中心</div>
  }
}
